<?php

/**
 * Class Shipping_Insurance_Model_Resource_Setup
 *
 * @category   Insurance
 * @package    Shipping_Insurance
 * @author     ae
 */

class Shipping_Insurance_Model_Resource_Setup extends Mage_Core_Model_Resource_Setup {

}